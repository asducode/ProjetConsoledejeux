var display_8h =
[
    [ "DISPLAY_draw_middle_line", "display_8h.html#a48e2334fdc0acdcfc6f772c8ebee5a70", null ],
    [ "DISPLAY_init", "display_8h.html#a7ffe3a1eb9de5d766a71c82b9e29479e", null ],
    [ "DISPLAY_refresh_ball", "display_8h.html#a0e8bac5c536c6e5312a976411d304c66", null ],
    [ "DISPLAY_refresh_racket", "display_8h.html#a4170b898c7164728e928b1ea86b6cc75", null ],
    [ "DISPLAY_show_scores", "display_8h.html#ae632c1543bd1c289a5bf0f5b6b9f8197", null ]
];