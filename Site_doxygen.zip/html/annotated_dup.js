var annotated_dup =
[
    [ "apple_t", "structapple__t.html", "structapple__t" ],
    [ "ball_t", "structball__t.html", "structball__t" ],
    [ "ballbreak_t", "structballbreak__t.html", null ],
    [ "ballfoot_t", "structballfoot__t.html", null ],
    [ "brick_t", "structbrick__t.html", null ],
    [ "bullet_t", "structbullet__t.html", "structbullet__t" ],
    [ "grid_t", "structgrid__t.html", null ],
    [ "playerfoot_t", "structplayerfoot__t.html", null ],
    [ "playertir_t", "structplayertir__t.html", "structplayertir__t" ],
    [ "positionsnake_t", "structpositionsnake__t.html", "structpositionsnake__t" ],
    [ "racket_t", "structracket__t.html", "structracket__t" ],
    [ "racketbreak_t", "structracketbreak__t.html", null ],
    [ "snake_t", "structsnake__t.html", "structsnake__t" ]
];