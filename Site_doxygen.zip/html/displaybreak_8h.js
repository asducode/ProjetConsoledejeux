var displaybreak_8h =
[
    [ "DISPLAYBREAK_init", "displaybreak_8h.html#afd0c6797a610c84d289b9b78592262e0", null ],
    [ "DISPLAYBREAK_refresh_ball", "displaybreak_8h.html#a77fd388c91de0d1a08adc7ccc4c6aa12", null ],
    [ "DISPLAYBREAK_refresh_grid", "displaybreak_8h.html#a8b27a12c8d71eadea1793c64b3fe768f", null ],
    [ "DISPLAYBREAK_refresh_life", "displaybreak_8h.html#aa83037b80c47c6c745434718e66f1fb0", null ],
    [ "DISPLAYBREAK_refresh_racket", "displaybreak_8h.html#abc8e011647b56e4c309c8efa649d9145", null ]
];