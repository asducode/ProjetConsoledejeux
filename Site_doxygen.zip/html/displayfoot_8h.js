var displayfoot_8h =
[
    [ "DISPLAYFOOT_draw_scores", "displayfoot_8h.html#a23b29b30513017c28cb33bffa554325a", null ],
    [ "DISPLAYFOOT_init", "displayfoot_8h.html#a55068bdf529f2ea32247b517f32a414f", null ],
    [ "DISPLAYFOOT_refresh_ball", "displayfoot_8h.html#ae9e8fc9de14fdbd1cbcafa832f468809", null ],
    [ "DISPLAYFOOT_refresh_players", "displayfoot_8h.html#a1b1d4f6cb627a4978885a5c58aa0615e", null ],
    [ "DISPLAYFOOT_show_field", "displayfoot_8h.html#a1c39299b22739bb3d3f0c59d966ee0ec", null ],
    [ "DISPLAYFOOT_show_winner", "displayfoot_8h.html#a1e44db71b86f4f3f7b53ea9910bee135", null ]
];