var pong_8h =
[
    [ "racket_t", "structracket__t.html", "structracket__t" ],
    [ "ball_t", "structball__t.html", "structball__t" ],
    [ "MARGIN_DEFAULT", "pong_8h.html#a9aa7b6071d49bc55bff6655967dbae3b", null ],
    [ "RACKET_HEIGHT", "pong_8h.html#ae43ec126eaff06a9a8c6a639c04d67aa", null ],
    [ "RACKET_SPEED", "pong_8h.html#a9a68a79039d7304de93118f453d4a1b3", null ],
    [ "RACKET_WIDTH", "pong_8h.html#acaca71ee7ffab297e129ff54e655e310", null ],
    [ "REFRESH_PERIOD_MS", "pong_8h.html#a927f3fbfb549f427b47b05167088ba0f", null ],
    [ "SCREEN_HEIGHT", "pong_8h.html#a6974d08a74da681b3957b2fead2608b8", null ],
    [ "SCREEN_WIDTH", "pong_8h.html#a2cd109632a6dcccaa80b43561b1ab700", null ],
    [ "ball_options_e", "pong_8h.html#aea0295c14c1c32a386d62574ddf8dc35", [
      [ "BALL_OPTION_NONE", "pong_8h.html#aea0295c14c1c32a386d62574ddf8dc35aa0dd792594e499c206806135fc64c79d", null ],
      [ "BALL_OPTION_JOKER", "pong_8h.html#aea0295c14c1c32a386d62574ddf8dc35a707dc1ffeb33cb17dc46a41ae0aa9863", null ],
      [ "BALL_OPTION_GLUE", "pong_8h.html#aea0295c14c1c32a386d62574ddf8dc35a08062a751ce72d75924755c4be5d81f2", null ],
      [ "BALL_OPTION_NB", "pong_8h.html#aea0295c14c1c32a386d62574ddf8dc35a320c4de1cab266216d2d4cfe9dbed279", null ]
    ] ],
    [ "game_state_t", "pong_8h.html#a4edce1ca040716922b6e4a79be4e414d", [
      [ "GAME_WAIT_START", "pong_8h.html#a4edce1ca040716922b6e4a79be4e414da29564c432d162a18a22873aaeb475958", null ],
      [ "GAME_RUNNING", "pong_8h.html#a4edce1ca040716922b6e4a79be4e414dafa3770814c2d9fbc78876d7ba4aa36ca", null ],
      [ "GAME_OVER", "pong_8h.html#a4edce1ca040716922b6e4a79be4e414da871723195985a4ae22d7e10d99bf8a00", null ]
    ] ],
    [ "DISPLAY_show_winner", "pong_8h.html#a60c9ec6d41b0ebcc4f49fe43b1810c67", null ],
    [ "PONG_init", "pong_8h.html#a9c9478aa5dc05a161fe6b0c4fbde6fb8", null ],
    [ "PONG_process_main", "pong_8h.html#a51cbf999385c4a6546d5d2089300898a", null ]
];