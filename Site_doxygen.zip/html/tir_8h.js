var tir_8h =
[
    [ "playertir_t", "structplayertir__t.html", "structplayertir__t" ],
    [ "bullet_t", "structbullet__t.html", "structbullet__t" ],
    [ "BULLET_SPEED", "tir_8h.html#a70b3e643b533b8f785b7912e69434161", null ],
    [ "MAX_BULLETS", "tir_8h.html#a4331843c2698da5ccb18562eb1485681", null ],
    [ "PLAYER_HEIGHT_TIR", "tir_8h.html#a6d693bce6a4b86bf74e9f4ba46f3dd26", null ],
    [ "PLAYER_SPEED", "tir_8h.html#af49bad41acef45feb40939c0cf9d5d35", null ],
    [ "PLAYER_WIDTH_TIR", "tir_8h.html#a58b7f9d237ced4c309d7500fd167082b", null ],
    [ "SCREEN_HEIGHT", "tir_8h.html#a6974d08a74da681b3957b2fead2608b8", null ],
    [ "SCREEN_WIDTH", "tir_8h.html#a2cd109632a6dcccaa80b43561b1ab700", null ],
    [ "gametir_state_t", "tir_8h.html#af161e86a1d12e253a507cd92746ee86b", [
      [ "TIR_GAME_WAIT_START", "tir_8h.html#af161e86a1d12e253a507cd92746ee86bacfd68378455a8873a684c4cf48cf81bf", null ],
      [ "TIR_GAME_RUNNING", "tir_8h.html#af161e86a1d12e253a507cd92746ee86bab589b570b03def5b8ce0aecc348b936d", null ],
      [ "TIR_GAME_OVER", "tir_8h.html#af161e86a1d12e253a507cd92746ee86ba69ec5a3b833fd0672583dfda4aba6489", null ]
    ] ],
    [ "TIR_check_collisions", "tir_8h.html#a892df9a36a9d0e7240a99fee2cd6515e", null ],
    [ "TIR_init", "tir_8h.html#ac006e6762b934b3410cf50f7de539bde", null ],
    [ "TIR_process_main", "tir_8h.html#af77387100a4a98a330a9326dc8a6b1c3", null ],
    [ "TIR_shoot", "tir_8h.html#ab8f6acab9fac47381d8a0f2baafd76d9", null ]
];