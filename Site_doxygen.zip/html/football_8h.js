var football_8h =
[
    [ "playerfoot_t", "structplayerfoot__t.html", null ],
    [ "ballfoot_t", "structballfoot__t.html", null ],
    [ "BALL_SIZE_FOOT", "football_8h.html#a6745f84c2e85b7c74723bf5044a367bc", null ],
    [ "BALL_SPEED_FOOT", "football_8h.html#ab28e9baba823e5c0699ca79323f9263f", null ],
    [ "GOAL_LENGTH", "football_8h.html#ac4029d34dc57b2100896f491fd34b92c", null ],
    [ "PLAYER_HEIGHT_FOOT", "football_8h.html#a743603a0d1eaaa02ff1bb04894b4e2b3", null ],
    [ "PLAYER_SPEED_FOOT", "football_8h.html#a04c036e38d8900297665473dcf584943", null ],
    [ "PLAYER_WIDTH_FOOT", "football_8h.html#a8b8d313bf1d7faed6ceecc2a1c41484b", null ],
    [ "SCREEN_HEIGHT", "football_8h.html#a6974d08a74da681b3957b2fead2608b8", null ],
    [ "SCREEN_WIDTH", "football_8h.html#a2cd109632a6dcccaa80b43561b1ab700", null ],
    [ "gamefoot_state_t", "football_8h.html#a8caecb42a8641198c707d348b3252965", [
      [ "FOOT_GAME_WAIT_START", "football_8h.html#a8caecb42a8641198c707d348b3252965aee2b07b7ea1e7d15b35ca7bb426c8691", null ],
      [ "FOOT_GAME_RUNNING", "football_8h.html#a8caecb42a8641198c707d348b3252965af41aa42c1dc530b7ef3aa76a5ad13627", null ],
      [ "FOOT_GAME_OVER", "football_8h.html#a8caecb42a8641198c707d348b3252965a05843d8e7935ca029cde942d9d740df0", null ]
    ] ],
    [ "FOOTBALL_init", "football_8h.html#a5ee7136a2d8732f9d701dcf148cca982", null ],
    [ "FOOTBALL_process_main", "football_8h.html#abca610a68a004ac6bef65ff87927397f", null ]
];