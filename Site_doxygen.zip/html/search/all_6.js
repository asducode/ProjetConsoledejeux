var searchData=
[
  ['health_0',['health',['../structplayertir__t.html#a5e043dc8944f480bddd4d37d101b953f',1,'playertir_t']]],
  ['height_1',['height',['../structracket__t.html#a7f55ee38e59917a8bfe86d1ed7b0bb69',1,'racket_t']]]
];
