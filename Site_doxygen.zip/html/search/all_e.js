var searchData=
[
  ['tir_2eh_0',['tir.h',['../tir_8h.html',1,'']]],
  ['tir_5fcheck_5fcollisions_1',['TIR_check_collisions',['../tir_8h.html#a892df9a36a9d0e7240a99fee2cd6515e',1,'tir.c']]],
  ['tir_5fgame_5fover_2',['TIR_GAME_OVER',['../tir_8h.html#af161e86a1d12e253a507cd92746ee86ba69ec5a3b833fd0672583dfda4aba6489',1,'tir.h']]],
  ['tir_5fgame_5frunning_3',['TIR_GAME_RUNNING',['../tir_8h.html#af161e86a1d12e253a507cd92746ee86bab589b570b03def5b8ce0aecc348b936d',1,'tir.h']]],
  ['tir_5fgame_5fwait_5fstart_4',['TIR_GAME_WAIT_START',['../tir_8h.html#af161e86a1d12e253a507cd92746ee86bacfd68378455a8873a684c4cf48cf81bf',1,'tir.h']]],
  ['tir_5finit_5',['TIR_init',['../tir_8h.html#ac006e6762b934b3410cf50f7de539bde',1,'tir.c']]],
  ['tir_5fprocess_5fmain_6',['TIR_process_main',['../tir_8h.html#af77387100a4a98a330a9326dc8a6b1c3',1,'tir.c']]],
  ['tir_5fshoot_7',['TIR_shoot',['../tir_8h.html#ab8f6acab9fac47381d8a0f2baafd76d9',1,'tir.c']]]
];
