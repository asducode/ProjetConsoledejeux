var searchData=
[
  ['tir_5fgame_5fover_0',['TIR_GAME_OVER',['../tir_8h.html#af161e86a1d12e253a507cd92746ee86ba69ec5a3b833fd0672583dfda4aba6489',1,'tir.h']]],
  ['tir_5fgame_5frunning_1',['TIR_GAME_RUNNING',['../tir_8h.html#af161e86a1d12e253a507cd92746ee86bab589b570b03def5b8ce0aecc348b936d',1,'tir.h']]],
  ['tir_5fgame_5fwait_5fstart_2',['TIR_GAME_WAIT_START',['../tir_8h.html#af161e86a1d12e253a507cd92746ee86bacfd68378455a8873a684c4cf48cf81bf',1,'tir.h']]]
];
