var searchData=
[
  ['snake_5finit_0',['snake_init',['../snake_8h.html#af14013239c879d88333a5d13af3b9336',1,'snake.c']]],
  ['snake_5fupdate_1',['snake_update',['../snake_8h.html#a9ad0c6652388f93a9690220ecca59e25',1,'snake.c']]]
];
