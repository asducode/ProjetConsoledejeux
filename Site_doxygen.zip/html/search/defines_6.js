var searchData=
[
  ['screen_5fheight_0',['SCREEN_HEIGHT',['../displaysnake_8h.html#a6974d08a74da681b3957b2fead2608b8',1,'SCREEN_HEIGHT:&#160;displaysnake.h'],['../football_8h.html#a6974d08a74da681b3957b2fead2608b8',1,'SCREEN_HEIGHT:&#160;football.h'],['../pong_8h.html#a6974d08a74da681b3957b2fead2608b8',1,'SCREEN_HEIGHT:&#160;pong.h'],['../tir_8h.html#a6974d08a74da681b3957b2fead2608b8',1,'SCREEN_HEIGHT:&#160;tir.h']]],
  ['screen_5fwidth_1',['SCREEN_WIDTH',['../displaysnake_8h.html#a2cd109632a6dcccaa80b43561b1ab700',1,'SCREEN_WIDTH:&#160;displaysnake.h'],['../football_8h.html#a2cd109632a6dcccaa80b43561b1ab700',1,'SCREEN_WIDTH:&#160;football.h'],['../pong_8h.html#a2cd109632a6dcccaa80b43561b1ab700',1,'SCREEN_WIDTH:&#160;pong.h'],['../tir_8h.html#a2cd109632a6dcccaa80b43561b1ab700',1,'SCREEN_WIDTH:&#160;tir.h']]]
];
