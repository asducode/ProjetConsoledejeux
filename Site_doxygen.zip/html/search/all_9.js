var searchData=
[
  ['margin_5fdefault_0',['MARGIN_DEFAULT',['../pong_8h.html#a9aa7b6071d49bc55bff6655967dbae3b',1,'pong.h']]],
  ['max_5fbullets_1',['MAX_BULLETS',['../tir_8h.html#a4331843c2698da5ccb18562eb1485681',1,'tir.h']]],
  ['max_5fsnake_5flength_2',['MAX_SNAKE_LENGTH',['../snake_8h.html#a3b57363c10b62b64db916289b0437cfb',1,'snake.h']]]
];
