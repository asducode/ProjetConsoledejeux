var searchData=
[
  ['player_5fheight_5ffoot_0',['PLAYER_HEIGHT_FOOT',['../football_8h.html#a743603a0d1eaaa02ff1bb04894b4e2b3',1,'football.h']]],
  ['player_5fheight_5ftir_1',['PLAYER_HEIGHT_TIR',['../tir_8h.html#a6d693bce6a4b86bf74e9f4ba46f3dd26',1,'tir.h']]],
  ['player_5fspeed_2',['PLAYER_SPEED',['../tir_8h.html#af49bad41acef45feb40939c0cf9d5d35',1,'tir.h']]],
  ['player_5fspeed_5ffoot_3',['PLAYER_SPEED_FOOT',['../football_8h.html#a04c036e38d8900297665473dcf584943',1,'football.h']]],
  ['player_5fwidth_5ffoot_4',['PLAYER_WIDTH_FOOT',['../football_8h.html#a8b8d313bf1d7faed6ceecc2a1c41484b',1,'football.h']]],
  ['player_5fwidth_5ftir_5',['PLAYER_WIDTH_TIR',['../tir_8h.html#a58b7f9d237ced4c309d7500fd167082b',1,'tir.h']]]
];
