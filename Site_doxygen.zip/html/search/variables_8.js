var searchData=
[
  ['prev_5fy_0',['prev_y',['../structplayertir__t.html#a191c8adeef4645126bd66376db99dd77',1,'playertir_t::prev_y'],['../structbullet__t.html#ab952adcd278f2b85e9251fbf94cf131a',1,'bullet_t::prev_y']]]
];
