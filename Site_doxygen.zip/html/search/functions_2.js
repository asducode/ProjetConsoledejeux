var searchData=
[
  ['football_5finit_0',['FOOTBALL_init',['../football_8h.html#a5ee7136a2d8732f9d701dcf148cca982',1,'football.c']]],
  ['football_5fprocess_5fmain_1',['FOOTBALL_process_main',['../football_8h.html#abca610a68a004ac6bef65ff87927397f',1,'football.c']]]
];
