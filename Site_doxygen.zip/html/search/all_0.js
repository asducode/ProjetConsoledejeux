var searchData=
[
  ['active_0',['active',['../structbullet__t.html#a99dd2ccb5ad5e7237bb596ff0734a7c1',1,'bullet_t']]],
  ['apple_5ft_1',['apple_t',['../structapple__t.html',1,'']]]
];
