var searchData=
[
  ['fine_5fx_0',['fine_x',['../structball__t.html#a957e1d62029f7d06bd0d321232e0b8a7',1,'ball_t']]],
  ['fine_5fy_1',['fine_y',['../structball__t.html#ae7fa3ce0b61da16abd2c5cd9100b07df',1,'ball_t']]],
  ['football_2eh_2',['football.h',['../football_8h.html',1,'']]],
  ['football_5finit_3',['FOOTBALL_init',['../football_8h.html#a5ee7136a2d8732f9d701dcf148cca982',1,'football.c']]],
  ['football_5fprocess_5fmain_4',['FOOTBALL_process_main',['../football_8h.html#abca610a68a004ac6bef65ff87927397f',1,'football.c']]]
];
