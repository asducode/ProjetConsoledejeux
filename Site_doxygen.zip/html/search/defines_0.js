var searchData=
[
  ['ball_5fsize_5ffoot_0',['BALL_SIZE_FOOT',['../football_8h.html#a6745f84c2e85b7c74723bf5044a367bc',1,'football.h']]],
  ['ball_5fspeed_5ffoot_1',['BALL_SPEED_FOOT',['../football_8h.html#ab28e9baba823e5c0699ca79323f9263f',1,'football.h']]],
  ['bullet_5fspeed_2',['BULLET_SPEED',['../tir_8h.html#a70b3e643b533b8f785b7912e69434161',1,'tir.h']]]
];
