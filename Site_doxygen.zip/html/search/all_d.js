var searchData=
[
  ['screen_5fheight_0',['SCREEN_HEIGHT',['../displaysnake_8h.html#a6974d08a74da681b3957b2fead2608b8',1,'SCREEN_HEIGHT:&#160;displaysnake.h'],['../football_8h.html#a6974d08a74da681b3957b2fead2608b8',1,'SCREEN_HEIGHT:&#160;football.h'],['../pong_8h.html#a6974d08a74da681b3957b2fead2608b8',1,'SCREEN_HEIGHT:&#160;pong.h'],['../tir_8h.html#a6974d08a74da681b3957b2fead2608b8',1,'SCREEN_HEIGHT:&#160;tir.h']]],
  ['screen_5fwidth_1',['SCREEN_WIDTH',['../displaysnake_8h.html#a2cd109632a6dcccaa80b43561b1ab700',1,'SCREEN_WIDTH:&#160;displaysnake.h'],['../football_8h.html#a2cd109632a6dcccaa80b43561b1ab700',1,'SCREEN_WIDTH:&#160;football.h'],['../pong_8h.html#a2cd109632a6dcccaa80b43561b1ab700',1,'SCREEN_WIDTH:&#160;pong.h'],['../tir_8h.html#a2cd109632a6dcccaa80b43561b1ab700',1,'SCREEN_WIDTH:&#160;tir.h']]],
  ['size_2',['size',['../structball__t.html#adc4a6b45a50a55ced35e7b9e4d5ce033',1,'ball_t']]],
  ['snake_2eh_3',['snake.h',['../snake_8h.html',1,'']]],
  ['snake_5finit_4',['snake_init',['../snake_8h.html#af14013239c879d88333a5d13af3b9336',1,'snake.c']]],
  ['snake_5ft_5',['snake_t',['../structsnake__t.html',1,'']]],
  ['snake_5fupdate_6',['snake_update',['../snake_8h.html#a9ad0c6652388f93a9690220ecca59e25',1,'snake.c']]],
  ['speed_7',['speed',['../structracket__t.html#aad56342988cb35a7188184d470f1c775',1,'racket_t']]],
  ['speed_5fx_8',['speed_x',['../structball__t.html#a020ed6ad16fcaed9d156c81e471e607c',1,'ball_t::speed_x'],['../structbullet__t.html#ae0912c9f13281d9b63f63e6c278f10f1',1,'bullet_t::speed_x']]],
  ['speed_5fy_9',['speed_y',['../structball__t.html#ac18f046c58cafa72b7e111cb878fa3fd',1,'ball_t']]]
];
