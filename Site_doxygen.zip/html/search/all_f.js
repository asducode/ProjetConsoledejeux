var searchData=
[
  ['updatepaddles_0',['updatePaddles',['../pong_8c.html#a7b60a1a0e8bd5c96bf8fc4b251ff90f0',1,'pong.c']]]
];
