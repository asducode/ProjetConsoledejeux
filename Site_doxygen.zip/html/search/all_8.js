var searchData=
[
  ['left_0',['left',['../structracket__t.html#ada7d3e842d8b4230b49b8d735449d83c',1,'racket_t']]],
  ['length_1',['length',['../structsnake__t.html#a07ee3c80ef8e483b4f62e689dfd5e2a7',1,'snake_t']]]
];
