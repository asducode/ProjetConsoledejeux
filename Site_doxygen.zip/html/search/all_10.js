var searchData=
[
  ['width_0',['width',['../structracket__t.html#a4a95c9cff5106486eeca29c42ef14064',1,'racket_t']]]
];
