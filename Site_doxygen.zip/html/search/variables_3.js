var searchData=
[
  ['fine_5fx_0',['fine_x',['../structball__t.html#a957e1d62029f7d06bd0d321232e0b8a7',1,'ball_t']]],
  ['fine_5fy_1',['fine_y',['../structball__t.html#ae7fa3ce0b61da16abd2c5cd9100b07df',1,'ball_t']]]
];
