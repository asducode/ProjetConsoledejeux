var searchData=
[
  ['game_5fstate_5ft_0',['game_state_t',['../pong_8h.html#a4edce1ca040716922b6e4a79be4e414d',1,'pong.h']]],
  ['gamefoot_5fstate_5ft_1',['gamefoot_state_t',['../football_8h.html#a8caecb42a8641198c707d348b3252965',1,'football.h']]],
  ['gametir_5fstate_5ft_2',['gametir_state_t',['../tir_8h.html#af161e86a1d12e253a507cd92746ee86b',1,'tir.h']]]
];
