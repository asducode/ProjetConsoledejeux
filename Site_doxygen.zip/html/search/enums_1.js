var searchData=
[
  ['directionsnake_5ft_0',['directionsnake_t',['../snake_8h.html#a2c045dc46d8eda17f31ea3861097ecea',1,'snake.h']]]
];
