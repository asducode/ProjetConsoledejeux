var searchData=
[
  ['player_5fheight_5ffoot_0',['PLAYER_HEIGHT_FOOT',['../football_8h.html#a743603a0d1eaaa02ff1bb04894b4e2b3',1,'football.h']]],
  ['player_5fheight_5ftir_1',['PLAYER_HEIGHT_TIR',['../tir_8h.html#a6d693bce6a4b86bf74e9f4ba46f3dd26',1,'tir.h']]],
  ['player_5fspeed_2',['PLAYER_SPEED',['../tir_8h.html#af49bad41acef45feb40939c0cf9d5d35',1,'tir.h']]],
  ['player_5fspeed_5ffoot_3',['PLAYER_SPEED_FOOT',['../football_8h.html#a04c036e38d8900297665473dcf584943',1,'football.h']]],
  ['player_5fwidth_5ffoot_4',['PLAYER_WIDTH_FOOT',['../football_8h.html#a8b8d313bf1d7faed6ceecc2a1c41484b',1,'football.h']]],
  ['player_5fwidth_5ftir_5',['PLAYER_WIDTH_TIR',['../tir_8h.html#a58b7f9d237ced4c309d7500fd167082b',1,'tir.h']]],
  ['playerfoot_5ft_6',['playerfoot_t',['../structplayerfoot__t.html',1,'']]],
  ['playertir_5ft_7',['playertir_t',['../structplayertir__t.html',1,'']]],
  ['pong_2ec_8',['pong.c',['../pong_8c.html',1,'']]],
  ['pong_2eh_9',['pong.h',['../pong_8h.html',1,'']]],
  ['pong_5finit_10',['PONG_init',['../pong_8c.html#a9c9478aa5dc05a161fe6b0c4fbde6fb8',1,'PONG_init(void):&#160;pong.c'],['../pong_8h.html#a9c9478aa5dc05a161fe6b0c4fbde6fb8',1,'PONG_init(void):&#160;pong.c']]],
  ['pong_5fprocess_5fmain_11',['PONG_process_main',['../pong_8c.html#a51cbf999385c4a6546d5d2089300898a',1,'PONG_process_main(void):&#160;pong.c'],['../pong_8h.html#a51cbf999385c4a6546d5d2089300898a',1,'PONG_process_main(void):&#160;pong.c']]],
  ['positionsnake_5ft_12',['positionsnake_t',['../structpositionsnake__t.html',1,'']]],
  ['prev_5fy_13',['prev_y',['../structplayertir__t.html#a191c8adeef4645126bd66376db99dd77',1,'playertir_t::prev_y'],['../structbullet__t.html#ab952adcd278f2b85e9251fbf94cf131a',1,'bullet_t::prev_y']]],
  ['projetconsoledejeux_14',['ProjetConsoledejeux',['../md__r_e_a_d_m_e.html',1,'ProjetConsoledejeux'],['../md__r_e_a_d_m_e.html#autotoc_md1',1,'ProjetConsoledejeux']]]
];
