var searchData=
[
  ['x_0',['x',['../structracket__t.html#a6ad3a96621181e2872b2b25c0038671c',1,'racket_t::x'],['../structball__t.html#a1a82e6425263fd7c586321004e0e4eae',1,'ball_t::x']]]
];
