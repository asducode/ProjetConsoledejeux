var searchData=
[
  ['game_5fover_0',['GAME_OVER',['../pong_8h.html#a4edce1ca040716922b6e4a79be4e414da871723195985a4ae22d7e10d99bf8a00',1,'pong.h']]],
  ['game_5frunning_1',['GAME_RUNNING',['../pong_8h.html#a4edce1ca040716922b6e4a79be4e414dafa3770814c2d9fbc78876d7ba4aa36ca',1,'pong.h']]],
  ['game_5fstate_5ft_2',['game_state_t',['../pong_8h.html#a4edce1ca040716922b6e4a79be4e414d',1,'pong.h']]],
  ['game_5fwait_5fstart_3',['GAME_WAIT_START',['../pong_8h.html#a4edce1ca040716922b6e4a79be4e414da29564c432d162a18a22873aaeb475958',1,'pong.h']]],
  ['gamefoot_5fstate_5ft_4',['gamefoot_state_t',['../football_8h.html#a8caecb42a8641198c707d348b3252965',1,'football.h']]],
  ['gametir_5fstate_5ft_5',['gametir_state_t',['../tir_8h.html#af161e86a1d12e253a507cd92746ee86b',1,'tir.h']]],
  ['goal_5flength_6',['GOAL_LENGTH',['../football_8h.html#ac4029d34dc57b2100896f491fd34b92c',1,'football.h']]],
  ['grid_5fheight_7',['GRID_HEIGHT',['../displaysnake_8h.html#a8bd9f95c4e7d0ae683aaa0434a72dca9',1,'displaysnake.h']]],
  ['grid_5ft_8',['grid_t',['../structgrid__t.html',1,'']]],
  ['grid_5fwidth_9',['GRID_WIDTH',['../displaysnake_8h.html#a804eeb9892adae7306540eb33f2326eb',1,'displaysnake.h']]]
];
