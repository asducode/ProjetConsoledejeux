var searchData=
[
  ['goal_5flength_0',['GOAL_LENGTH',['../football_8h.html#ac4029d34dc57b2100896f491fd34b92c',1,'football.h']]],
  ['grid_5fheight_1',['GRID_HEIGHT',['../displaysnake_8h.html#a8bd9f95c4e7d0ae683aaa0434a72dca9',1,'displaysnake.h']]],
  ['grid_5fwidth_2',['GRID_WIDTH',['../displaysnake_8h.html#a804eeb9892adae7306540eb33f2326eb',1,'displaysnake.h']]]
];
