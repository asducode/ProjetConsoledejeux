var searchData=
[
  ['dir_0',['dir',['../structsnake__t.html#ac024eca360eb730b950a7d29f039df3a',1,'snake_t']]]
];
