var searchData=
[
  ['playerfoot_5ft_0',['playerfoot_t',['../structplayerfoot__t.html',1,'']]],
  ['playertir_5ft_1',['playertir_t',['../structplayertir__t.html',1,'']]],
  ['positionsnake_5ft_2',['positionsnake_t',['../structpositionsnake__t.html',1,'']]]
];
