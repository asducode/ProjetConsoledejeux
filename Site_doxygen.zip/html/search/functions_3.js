var searchData=
[
  ['pong_5finit_0',['PONG_init',['../pong_8c.html#a9c9478aa5dc05a161fe6b0c4fbde6fb8',1,'PONG_init(void):&#160;pong.c'],['../pong_8h.html#a9c9478aa5dc05a161fe6b0c4fbde6fb8',1,'PONG_init(void):&#160;pong.c']]],
  ['pong_5fprocess_5fmain_1',['PONG_process_main',['../pong_8c.html#a51cbf999385c4a6546d5d2089300898a',1,'PONG_process_main(void):&#160;pong.c'],['../pong_8h.html#a51cbf999385c4a6546d5d2089300898a',1,'PONG_process_main(void):&#160;pong.c']]]
];
