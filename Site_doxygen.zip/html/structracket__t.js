var structracket__t =
[
    [ "height", "structracket__t.html#a7f55ee38e59917a8bfe86d1ed7b0bb69", null ],
    [ "left", "structracket__t.html#ada7d3e842d8b4230b49b8d735449d83c", null ],
    [ "right", "structracket__t.html#aa179f14d3b012334975b5261434846ef", null ],
    [ "speed", "structracket__t.html#aad56342988cb35a7188184d470f1c775", null ],
    [ "width", "structracket__t.html#a4a95c9cff5106486eeca29c42ef14064", null ],
    [ "x", "structracket__t.html#a6ad3a96621181e2872b2b25c0038671c", null ],
    [ "y", "structracket__t.html#a0e1ee35dc02eb43ded066f4d9aa31e7f", null ]
];