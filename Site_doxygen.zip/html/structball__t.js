var structball__t =
[
    [ "fine_x", "structball__t.html#a957e1d62029f7d06bd0d321232e0b8a7", null ],
    [ "fine_y", "structball__t.html#ae7fa3ce0b61da16abd2c5cd9100b07df", null ],
    [ "joker", "structball__t.html#a994d5203111ea4082e20a7e0ee8a0b3c", null ],
    [ "options", "structball__t.html#a0b0e8493d2dd47da0b2a8db8ab3cc456", null ],
    [ "size", "structball__t.html#adc4a6b45a50a55ced35e7b9e4d5ce033", null ],
    [ "speed_x", "structball__t.html#a020ed6ad16fcaed9d156c81e471e607c", null ],
    [ "speed_y", "structball__t.html#ac18f046c58cafa72b7e111cb878fa3fd", null ],
    [ "x", "structball__t.html#a1a82e6425263fd7c586321004e0e4eae", null ],
    [ "y", "structball__t.html#a0fbe4ec3d4e4c479a651b797a2e8c982", null ]
];