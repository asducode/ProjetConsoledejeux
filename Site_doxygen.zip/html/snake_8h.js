var snake_8h =
[
    [ "positionsnake_t", "structpositionsnake__t.html", "structpositionsnake__t" ],
    [ "snake_t", "structsnake__t.html", "structsnake__t" ],
    [ "apple_t", "structapple__t.html", "structapple__t" ],
    [ "MAX_SNAKE_LENGTH", "snake_8h.html#a3b57363c10b62b64db916289b0437cfb", null ],
    [ "directionsnake_t", "snake_8h.html#a2c045dc46d8eda17f31ea3861097ecea", [
      [ "DIR_UP", "snake_8h.html#a2c045dc46d8eda17f31ea3861097eceaa0b76fb863426c07c6c997a8d9523257b", null ],
      [ "DIR_DOWN", "snake_8h.html#a2c045dc46d8eda17f31ea3861097eceaab1bf68da897d09488069dd40e54f442d", null ],
      [ "DIR_LEFT", "snake_8h.html#a2c045dc46d8eda17f31ea3861097eceaa1307dc42d06472935155dcbe283bc660", null ],
      [ "DIR_RIGHT", "snake_8h.html#a2c045dc46d8eda17f31ea3861097eceaa5dd21ef3d450f62c44082756cab8f6f8", null ]
    ] ],
    [ "snake_init", "snake_8h.html#af14013239c879d88333a5d13af3b9336", null ],
    [ "snake_update", "snake_8h.html#a9ad0c6652388f93a9690220ecca59e25", null ]
];