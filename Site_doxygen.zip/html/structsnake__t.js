var structsnake__t =
[
    [ "body", "structsnake__t.html#ab7185bcb6fde910c7d6dd7754b47587b", null ],
    [ "dir", "structsnake__t.html#ac024eca360eb730b950a7d29f039df3a", null ],
    [ "length", "structsnake__t.html#a07ee3c80ef8e483b4f62e689dfd5e2a7", null ]
];