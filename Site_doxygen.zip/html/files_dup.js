var files_dup =
[
    [ "breakbricks.h", "breakbricks_8h_source.html", null ],
    [ "button.h", "button_8h_source.html", null ],
    [ "config.h", "config_8h.html", null ],
    [ "display.h", "display_8h.html", "display_8h" ],
    [ "displaybreak.h", "displaybreak_8h.html", "displaybreak_8h" ],
    [ "displayfoot.h", "displayfoot_8h.html", "displayfoot_8h" ],
    [ "displaysnake.h", "displaysnake_8h.html", "displaysnake_8h" ],
    [ "displaytir.h", "displaytir_8h.html", "displaytir_8h" ],
    [ "football.h", "football_8h.html", "football_8h" ],
    [ "pong.c", "pong_8c.html", "pong_8c" ],
    [ "pong.h", "pong_8h.html", "pong_8h" ],
    [ "snake.h", "snake_8h.html", "snake_8h" ],
    [ "tir.h", "tir_8h.html", "tir_8h" ]
];