var displaysnake_8h =
[
    [ "CELL_SIZE", "displaysnake_8h.html#a7a4127f14f16563da90eb3c836bc404f", null ],
    [ "GRID_HEIGHT", "displaysnake_8h.html#a8bd9f95c4e7d0ae683aaa0434a72dca9", null ],
    [ "GRID_WIDTH", "displaysnake_8h.html#a804eeb9892adae7306540eb33f2326eb", null ],
    [ "SCREEN_HEIGHT", "displaysnake_8h.html#a6974d08a74da681b3957b2fead2608b8", null ],
    [ "SCREEN_WIDTH", "displaysnake_8h.html#a2cd109632a6dcccaa80b43561b1ab700", null ],
    [ "DISPLAYSNAKE_clear", "displaysnake_8h.html#a393587783e8ad30fd211f31ce43509c7", null ],
    [ "DISPLAYSNAKE_draw_scores", "displaysnake_8h.html#abcb8ace44c78805fee79663d5e5701ea", null ],
    [ "DISPLAYSNAKE_erase_snake", "displaysnake_8h.html#a9cac47f6c3638e80da8315f4beaaa8f4", null ],
    [ "DISPLAYSNAKE_init", "displaysnake_8h.html#ab07d5dbc8c9ce2d085437331c14fb2a8", null ],
    [ "DISPLAYSNAKE_refresh_apple", "displaysnake_8h.html#a1c072d7f2fa5de1de55be8d5b6f72c83", null ],
    [ "DISPLAYSNAKE_refresh_snake", "displaysnake_8h.html#a7d967f6e84c52683cccca10ca75871b0", null ]
];