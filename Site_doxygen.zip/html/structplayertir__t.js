var structplayertir__t =
[
    [ "health", "structplayertir__t.html#a5e043dc8944f480bddd4d37d101b953f", null ],
    [ "prev_y", "structplayertir__t.html#a191c8adeef4645126bd66376db99dd77", null ],
    [ "y", "structplayertir__t.html#abf088d7785046c4f5b3b13b22c911bb9", null ]
];