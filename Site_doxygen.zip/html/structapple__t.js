var structapple__t =
[
    [ "y", "structapple__t.html#a54da98cd5e8846832ab526c86f704c35", null ]
];