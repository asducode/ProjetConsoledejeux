var pong_8c =
[
    [ "checkGameOver", "pong_8c.html#a47df39cc446bfc36db6289cc2c9ff096", null ],
    [ "checkPaddleCollision", "pong_8c.html#a7ff808da61a8e9f891af044614f70ff6", null ],
    [ "checkScore", "pong_8c.html#a37f1c0bbeaa6eff4e9e842b19e10e7db", null ],
    [ "checkWallCollision", "pong_8c.html#a10ecdf26228f59ddfc4260ac3b6bb3cf", null ],
    [ "DISPLAY_show_winner", "pong_8c.html#a60c9ec6d41b0ebcc4f49fe43b1810c67", null ],
    [ "PONG_init", "pong_8c.html#a9c9478aa5dc05a161fe6b0c4fbde6fb8", null ],
    [ "PONG_process_main", "pong_8c.html#a51cbf999385c4a6546d5d2089300898a", null ],
    [ "updatePaddles", "pong_8c.html#a7b60a1a0e8bd5c96bf8fc4b251ff90f0", null ]
];