var displaytir_8h =
[
    [ "DISPLAY_TIR_draw_health", "displaytir_8h.html#aaa6ebd39824240e6fa121447c5687885", null ],
    [ "DISPLAY_TIR_erase_bullet", "displaytir_8h.html#a886b2bbc8a6e76d61629d993dd219b9a", null ],
    [ "DISPLAY_TIR_init", "displaytir_8h.html#ab762f3b872d3bc6013db84676ed33a72", null ],
    [ "DISPLAY_TIR_refresh_bullets", "displaytir_8h.html#ac2c0fe5fc216d25bc04dea7160e8da23", null ],
    [ "DISPLAY_TIR_refresh_players", "displaytir_8h.html#addfe64d4666c13f6a4b28a329063ab7f", null ],
    [ "DISPLAY_TIR_show_winner", "displaytir_8h.html#ac03a44e1770d8f0a71bbc07615006192", null ]
];