var structbullet__t =
[
    [ "active", "structbullet__t.html#a99dd2ccb5ad5e7237bb596ff0734a7c1", null ],
    [ "prev_y", "structbullet__t.html#ab952adcd278f2b85e9251fbf94cf131a", null ],
    [ "speed_x", "structbullet__t.html#ae0912c9f13281d9b63f63e6c278f10f1", null ],
    [ "y", "structbullet__t.html#a50bbd427a6a2bfe4e671cd71b285eb76", null ]
];